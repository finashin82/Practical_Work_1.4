﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        /// <summary>
        /// Запуск программы
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World !!!");

            Console.Write("Hello ");
            Console.Write("World ");
            Console.Write("!!!");            

            Console.ReadLine();
        }
    }
}
